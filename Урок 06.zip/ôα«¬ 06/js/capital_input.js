function capitalize(textboxid, str) {
            if (str && str.length >= 1)
            {
                var firstChar = str.charAt(0);
                var remainingStr = str.slice(1);
                str = firstChar.toUpperCase() + remainingStr;
            }
            document.getElementById(textboxid).value = str;
        }

function capitalizeSentences(capText, capLock)
        {
            if (capLock == 1 || capLock == true)
            {
                capText = capText.toLowerCase();
            }

            capText = capText.replace(/.n/g, ".[-<br>-]. ");
            capText = capText.replace(/.sn/g, ". [-<br>-]. ");
            var wordSplit = '. ';

            var wordArray = capText.split(wordSplit);

            var numWords = wordArray.length;

            for(x = 0; x < numWords; x++)
            {
                wordArray[x] = wordArray[x].replace(wordArray[x].charAt(0), wordArray[x].charAt(0).toUpperCase());
                if (x == 0)
                {
                    capText = wordArray[x] + ". ";
                }
                else if(x != numWords - 1)
                {
                    capText = capText + wordArray[x] + ". ";
                }
                else if(x == numWords - 1)
                {
                    capText = capText + wordArray[x];
                }
            }
            capText = capText.replace(/[-<br>-].s/g, "n");
            capText = capText.replace(/sis/g, " I ");
            return capText;
        }